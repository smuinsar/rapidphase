"""Tiling utilities for large image processing."""

from fastphase.tiling.tile_manager import TileManager

__all__ = ["TileManager"]
